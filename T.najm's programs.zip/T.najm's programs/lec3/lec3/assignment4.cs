﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec3
{
    public partial class assignment4 : Form
    {
        int n;
        public assignment4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void assignment4_Load(object sender, EventArgs e)
        {
            label1.Text = "enter the number";
            label2.Text = "result of sum";
            label3.Text = "result of fact";
            label4.Text = "result of root";
            sum.Text = "sum";
            fact.Text = "fact";
            root.Text = "root";
            textBox1.Focus();
        }

        private void fact_Click(object sender, EventArgs e)
        {
             long f = 1;
            //n = Convert.ToInt32(textBox1.Text); بدلها الاف
            if (int.TryParse(textBox1.Text, out n))
            {
                for (int i = 1; i <= n; i++)
                    f *= i;
                label3.Text = f.ToString();
            }
            else
                MessageBox.Show("the number is error");

        }

        private void sum_Click(object sender, EventArgs e)
        {
            long x = 0;
            if (int.TryParse(textBox1.Text, out n))
            //n = Convert.ToInt32(textBox1.Text);
            {
                for (int i = 1; i <= n; i++)
                    x += i;
                //n = (n * (n + 1)) / 2; بدل الفور
                label2.Text = x.ToString();
            }
            else
                MessageBox.Show("the number is error");
        }
        private void root_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out n))

                if (n == 1)
                {
                    label4.Text = "1";
                    return;
                }
                else if (n < 0)
                {
                    MessageBox.Show("لا يمكن ايجاد جذر لعدد سالب:");
                    return;
                }
                else if (n > 0)
                {
                    label4.Text= Math.Sqrt(n).ToString();
                    return;
                }
                else
                    MessageBox.Show("the number is error");
        }
    }
}
