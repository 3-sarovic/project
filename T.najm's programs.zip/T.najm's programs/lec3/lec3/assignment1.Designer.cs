﻿namespace lec3
{
    partial class assignment1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textnumber1 = new System.Windows.Forms.TextBox();
            this.textopration1 = new System.Windows.Forms.TextBox();
            this.textnumber2 = new System.Windows.Forms.TextBox();
            this.textopration2 = new System.Windows.Forms.TextBox();
            this.textnumber3 = new System.Windows.Forms.TextBox();
            this.textresult = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textnumber1
            // 
            this.textnumber1.Location = new System.Drawing.Point(32, 12);
            this.textnumber1.Name = "textnumber1";
            this.textnumber1.Size = new System.Drawing.Size(100, 24);
            this.textnumber1.TabIndex = 0;
            // 
            // textopration1
            // 
            this.textopration1.Location = new System.Drawing.Point(32, 53);
            this.textopration1.Name = "textopration1";
            this.textopration1.Size = new System.Drawing.Size(100, 24);
            this.textopration1.TabIndex = 1;
            // 
            // textnumber2
            // 
            this.textnumber2.Location = new System.Drawing.Point(32, 91);
            this.textnumber2.Name = "textnumber2";
            this.textnumber2.Size = new System.Drawing.Size(100, 24);
            this.textnumber2.TabIndex = 2;
            this.textnumber2.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textopration2
            // 
            this.textopration2.Location = new System.Drawing.Point(32, 133);
            this.textopration2.Name = "textopration2";
            this.textopration2.Size = new System.Drawing.Size(100, 24);
            this.textopration2.TabIndex = 3;
            // 
            // textnumber3
            // 
            this.textnumber3.Location = new System.Drawing.Point(32, 172);
            this.textnumber3.Name = "textnumber3";
            this.textnumber3.Size = new System.Drawing.Size(100, 24);
            this.textnumber3.TabIndex = 4;
            // 
            // textresult
            // 
            this.textresult.Location = new System.Drawing.Point(32, 215);
            this.textresult.Name = "textresult";
            this.textresult.Size = new System.Drawing.Size(100, 24);
            this.textresult.TabIndex = 5;
            this.textresult.TextChanged += new System.EventHandler(this.textresult_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = ":العدد الاول";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(194, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "العملية";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(168, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "العدد الثاني";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(194, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "العملية";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "العدد الثالث";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(205, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "الناتج";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.Location = new System.Drawing.Point(168, 269);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 47);
            this.button1.TabIndex = 12;
            this.button1.Text = "حساب";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(32, 269);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 47);
            this.button2.TabIndex = 13;
            this.button2.Text = "اغلاق";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // assignment1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 328);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textresult);
            this.Controls.Add(this.textnumber3);
            this.Controls.Add(this.textopration2);
            this.Controls.Add(this.textnumber2);
            this.Controls.Add(this.textopration1);
            this.Controls.Add(this.textnumber1);
            this.Name = "assignment1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.assignment1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textnumber1;
        private System.Windows.Forms.TextBox textopration1;
        private System.Windows.Forms.TextBox textnumber2;
        private System.Windows.Forms.TextBox textopration2;
        private System.Windows.Forms.TextBox textnumber3;
        private System.Windows.Forms.TextBox textresult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

