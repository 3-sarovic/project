﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H.W1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //public void my_keypress(object sender, KeyPressEventArgs e)
        //{
        //    if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) &&
        //    (e.KeyChar != '-' || (sender as TextBox).SelectionStart != 0) &&
        //    (e.KeyChar != '.' || (sender as TextBox).Text.IndexOf('.') > -1 || (sender as TextBox).Text.Length == 0))
        //        e.Handled = true;
        //// (sender,e)في حال انه انفذها هي بكتب بال كاي برس حق الاثنين البوكسات استدعاء لها فقط عن طريق اسمها والباراميتر سندر واي 
        //}

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.TextChanged += textBox2_TextChanged;
            textBox1.KeyPress += textBox2_KeyPress;
            
            button1.Enabled = button2.Enabled = button3.Enabled =
button4.Enabled = false;
            textBox3.ReadOnly = true; 
            this.Text = "calculator";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text)+ Convert.ToDouble(textBox2.Text)).ToString();

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) * Convert.ToDouble(textBox2.Text)).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {    if (Convert.ToDouble(textBox2.Text) != 0)
                textBox3.Text = (Convert.ToDouble(textBox1.Text) / Convert.ToDouble(textBox2.Text)).ToString();
            else
                MessageBox.Show("we can't be divided by zero","error", MessageBoxButtons.YesNoCancel);
        


        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox3.Text = (Convert.ToDouble(textBox1.Text) - Convert.ToDouble(textBox2.Text)).ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button4.Enabled=button3.Enabled=button2.Enabled= button1.Enabled = 
            (textBox1.Text != "") && (textBox2.Text != ""); 
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            
           if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && 
            (e.KeyChar!= '-' || (sender as TextBox).SelectionStart !=0) &&
            (e.KeyChar != '.' || (sender as TextBox).Text.IndexOf('.')>-1 || (sender as TextBox).Text.Length ==0))
                e.Handled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {    
            this .Close();
        }
    }
}
